package com.localhost.roadaccidentinfo.DTO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CountCityDTO {

    private Integer countIdx;

    private String city;

    private Integer accidentOccurCnt;
    private Integer accidentCasltCnt;
    private Integer accidentDprCnt;
    private Integer accidentSerinjuryCnt;
    private Integer accidentSltinjuryCnt;
    private Integer accidentInjuryCnt;
}
