package com.localhost.roadaccidentinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoadaccidentinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoadaccidentinfoApplication.class, args);
	}

}
